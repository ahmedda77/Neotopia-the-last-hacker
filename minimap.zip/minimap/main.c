#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "minimap.h"

int main() {
	SDL_Event event;
	TTF_Font *police;
	SDL_Init( SDL_INIT_VIDEO| SDL_INIT_AUDIO) ;
	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);
	TTF_Init();
    	minimap m;
	Mix_Music* musique;
    	SDL_Surface *screen = NULL;
	int continuer = 1;
    	Uint32 temps;
	SDL_Rect posJoueur;
        SDL_Rect camera;
        int redimensionnement=5;
	SDL_Rect pos_joueur_minimap;
	screen = SDL_SetVideoMode(1920, 1080,  32,SDL_HWSURFACE | SDL_DOUBLEBUF);
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("Echec d'initialisation de SDL : %s\n", SDL_GetError());
		return 1;
	}
	police= TTF_OpenFont( "exemple.ttf", 24 );
	musique = Mix_LoadMUS("Copyright Free Military Music  Legionnaire by ScottBuckley.mp3");
	Mix_PlayMusic(musique, -1);
	initmap(&m);
    	while(continuer) {
        	while(SDL_PollEvent(&event)) {
            		switch (event.type) {
                		case SDL_QUIT:
                    			continuer=0;
                    			break;

                		case SDL_KEYDOWN:
                    			switch (event.key.keysym.sym) {
                        			case SDLK_ESCAPE:
                            				continuer=0;
                            				break;
                        			case SDLK_e:
                            				continuer=0;
                            				break;
                    			}
                   			break;
			}
        	}
        	SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
        	afficherminimap(m, screen);
		animerMinimap(&m, screen);
        	pos_joueur_minimap = MAJMinimap(posJoueur, redimensionnement, camera);
		SDL_Flip(screen);
        	affichertemp(&temps,screen,police);
		SDL_Flip(screen);
        	SDL_Delay(10);
    	}
    	SDL_FreeSurface(m.img_map);
    	SDL_FreeSurface(m.img_joueur);
    	SDL_Quit();
    	return 0;
}
