#ifndef PERSO_H
#define PERSO_H
#include"perso.h"
#include <SDL/SDL.h>



#define SPRITE_WIDTH 64
#define SPRITE_HEIGHT 64
#define GRAVITY 1

typedef struct {
    SDL_Surface *image[6];
    
    SDL_Rect position;
	
    int velocity;
    int frame;
	int frameh;
    int status;
    int left;
    int right;
    int up;

   
} Person;

void init_person(Person *person);

void move_right(Person *person);
void handleKeyPress(SDL_Event event, Person *person);
void handleKeyRelease(SDL_Event event, Person *person);
void move_left(Person *person);
void handleKeyPressleft(SDL_Event event, Person *person);
void handleKeyReleaseleft(SDL_Event event, Person *person);
void sautVertical(Person *perso, int dt, int seuil);
void handleKeyPressup(SDL_Event event, Person *person);
void handleKeyReleaseup(SDL_Event event, Person *person);


#endif

