#include "perso.h"
#define PERSON_VELOCITY 10
#define JUMP_VELOCITY 10
#include <SDL/SDL_image.h>
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480
#define PERSON_WIDTH 200
#define PERSON_HEIGHT 200
#define IMAGE_SWITCH_INTERVAL 700 
#include <SDL/SDL.h>
#define FRAME_DELAY_MS 25

void init_person(Person *person) {

	person->image[0] = IMG_Load("personne1.png");
	person->image[1] = IMG_Load("personne2.png");
	person->image[2] = IMG_Load("personne3.png");
	person->image[3] = IMG_Load("PERSONNE1.png");
	person->image[4] = IMG_Load("PERSONNE2.png");
	person->image[5] = IMG_Load("PERSONNE3.png");
	
	
	if (!person->image) {
        fprintf(stderr, "Failed to load PERSONNE image: %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
    }
 person->position.x = SCREEN_WIDTH / 2 - PERSON_WIDTH / 2;
    person->position.y = SCREEN_HEIGHT - PERSON_HEIGHT;
    person->position.w = PERSON_WIDTH;
    person->position.h = PERSON_HEIGHT;

 
	
    person->velocity = 0;
    person->frame = 0;
    person->status = 0;


}


void move_right(Person *person) {
	Uint32 startTime = SDL_GetTicks();
    person->position.x += PERSON_VELOCITY;
    
   
    if (person->position.x > 600) {
        person->position.x = 600;
    }
	if (PERSON_VELOCITY != 0) {
        person->frame = (person->frame + 1) % 3; 
    }
	
       
Uint32 elapsedTime = SDL_GetTicks() - startTime; 

    if (elapsedTime < FRAME_DELAY_MS) {
        SDL_Delay(60 - elapsedTime);
    }
}

void handleKeyPress(SDL_Event event, Person *person) {
    if (event.key.keysym.sym == SDLK_RIGHT) {
       person->right=1;
	person->left=0;
    }
}
void handleKeyRelease(SDL_Event event, Person *person) {
    if (event.key.keysym.sym == SDLK_RIGHT) {
        person->right = 0; 
    }
}
//////////////////////////////////////////////////////////////////////
void move_left(Person *person) {

	Uint32 startTime = SDL_GetTicks();
    person->position.x -= PERSON_VELOCITY;
    
   
    if (person->position.x < 0) {
        person->position.x = 0;
    }
	
        if (PERSON_VELOCITY != 0) {
        person->frame = (person->frame + 1) % 3+3; 
    } 

}

void handleKeyPressleft(SDL_Event event, Person *person) {
    if (event.key.keysym.sym == SDLK_LEFT) {
       person->left=1;
	person->right=0;
    }
}
void handleKeyReleaseleft(SDL_Event event, Person *person) {
    if (event.key.keysym.sym == SDLK_LEFT) {
        person->left = 0; 
    }
}
///////////////////////////////////////////////////////////////////
void handleKeyPressup(SDL_Event event, Person *person) {
    if (event.key.keysym.sym == SDLK_SPACE) {
       person->up=1;
	
    }
}
void handleKeyReleaseup(SDL_Event event, Person *person) {
Uint32 startTime = SDL_GetTicks();
    if (event.key.keysym.sym == SDLK_SPACE) {
        person->up = 0; 
	Uint32 elapsedTime = SDL_GetTicks() - startTime; 

    if (elapsedTime < FRAME_DELAY_MS) {
        SDL_Delay(100 - elapsedTime);
    }
	person->position.y = 300;
	
    }
}
void sautVertical(Person *person, int dt, int posinit) {

    
    float a = 0.0005; 
    float c = posinit; 
	posinit=person->position.y;
    
    if (person->up) {

     
        float y = a * (dt * dt) + c;

if (person->frame >= 3) {
    person->position.x -= 40;
} else {
    person->position.x -= -40;
}
	
	
			
      
        person->position.y = (int)y; 

         if (person->position.x > 600) {
        person->position.x = 600;
    }else  if (person->position.x < 0) {
        person->position.x = 0;
    }
    }
}



