#include <SDL/SDL.h>
#include "perso.h"
#include <SDL/SDL_image.h>
#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#include <SDL/SDL_ttf.h>

int main() {
    Person person; 
	
    SDL_Surface *screen;
	SDL_Event event;
    int running = 1;
    int posinit;
    int dt;
    int score = 0;
	
   
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL initialization failed: %s\n", SDL_GetError());
        return 1;
    }


    if (TTF_Init() != 0) {
        printf("SDL_ttf initialization failed: %s\n", TTF_GetError());
        SDL_Quit();
        return 1;
    }


    TTF_Font* font = TTF_OpenFont("arial.ttf", 24); 
    if (font == NULL) {
        printf("Failed to load font: %s\n", TTF_GetError());
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

  
    screen = SDL_SetVideoMode(1920, 1080, 32, SDL_SWSURFACE);
    if (!screen) {
        printf("Failed to create window: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    init_person(&person);
    
    const Uint8 *keystate = SDL_GetKeyState(NULL);
	const int FPS = 60;
    const int frameDelay = 1000 / FPS;
    Uint32 frameStart;
    int frameTime;

    while (running) {
        Uint32 startTime = SDL_GetTicks(); 

        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    running = 0;
                    break;
                case SDL_KEYDOWN:
                    if (keystate[SDLK_SPACE]) {
                        person.up = 1;
                    }
                    handleKeyPress(event, &person);
                    handleKeyPressleft(event, &person);
                    handleKeyPressup(event, &person);
                    break;
                case SDL_KEYUP:
                    handleKeyRelease(event, &person);
                    handleKeyReleaseleft(event, &person);
                    handleKeyReleaseup(event, &person);
                    break;
            }
        }

        if (person.right == 1) {
            move_right(&person);
            score += 10;
        }
        if (person.left == 1) {
            move_left(&person);
        }
        if(person.up == 1) {
            sautVertical(&person,  dt,  posinit);
	   score += 10;
        }

       
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));


        SDL_Rect dest_rect = { person.position.x, person.position.y, person.position.w, person.position.h };
        SDL_BlitSurface(person.image[person.frame], NULL, screen, &dest_rect);

       
        char scoreText[10]; 
        sprintf(scoreText, "Score: %d", score);
        SDL_Color textColor = {255, 255, 255}; 
        SDL_Surface* textSurface = TTF_RenderText_Solid(font, scoreText, textColor);
        SDL_Rect dstRectttf = {10, 10, 0, 0}; 
        SDL_BlitSurface(textSurface, NULL, screen, &dstRectttf);
        SDL_FreeSurface(textSurface); 

        SDL_Flip(screen);

        
        Uint32 elapsedTime = SDL_GetTicks() - startTime; 
        if (elapsedTime < 16) { 
            SDL_Delay(60 - elapsedTime); 
        }
    }

    
    SDL_FreeSurface(screen);
    	
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();

    return 0;
}

